from django.urls import path
from app import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import LoginForm , MyPasswordChangeForm

urlpatterns = [
    # path('', views.home),
    path('', views.ProductView.as_view(), name="home"),
    path('product-detail/<int:pk>', views.ProductDetailView.as_view(), name='product-detail'),
    path('add-to-cart/', views.add_to_cart, name='add-to-cart'),
    path('cart/', views.show_cart, name='showcart'),

    path('pluscart/', views.plus_cart),
    path('minuscart/', views.minus_cart),
    path('removecart/', views.remove_cart, name='removecart'),

    # path('pluspcart/', views.plus_pcart),

    path('print/', views.PrintFileView.as_view(), name='print'),
    # path('print/', views.fileupload, name='print'),
    path('printview/', views.print_view, name='printview'),
    path('add-print-cart/', views.add_print_cart, name='addprintcart'),
    path('pcart/', views.print_show_cart, name ='pcart'),
    path('removepcart/', views.remove_pcart, name ='removepcart'),


    path('checkout/', views.checkout, name='checkout'),
    path('printcheckout/', views.printcheckout, name='printcheckout'),
    path('paymentdone/', views.payment_done, name='paymentdone'),

    path('printpaymentdone/', views.print_payment_done, name='printpaymentdone'),

    path('orders/', views.orders, name='orders'),
    path('printorders/', views.printorders, name='printorders'),
    path('orderupdate/<int:id>/<int:pid>/', views.orderupdate, name='orderupdate'),
    path('prod_orderupdate/<int:id>/', views.prod_orderupdate, name='prod_orderupdate'),
    path('orderdelivered/', views.orders_by_delivered, name = 'orderdelivered'),
   


    path('orderview/', views.OrderPlacedView.as_view(), name='orderview'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('address/', views.address, name='address'),
    # path('uploads/', views.print_file, name='uploads'),
    
    path('sationery/', views.sationery, name='sationery'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='app/login.html',authentication_form=LoginForm), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('passwordchange/', auth_views.PasswordChangeView.as_view(template_name='app/passwordchange.html', form_class=MyPasswordChangeForm, success_url='/'), name='passwordchange'),
    path('registration/', views.CustomerRegistrationView.as_view(), name='customerregistration'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
